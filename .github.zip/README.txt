COPY ICON CLEAN FIX — v39

Replace all three included files.

Fixes:
- Removes the accidental self-import from Copy.svg.tsx.
- Removes the accidental CopyIcon import from NPS copy.svg.tsx.
- Removes MUI ContentCopyRounded from CurrentInterventionPage.tsx.
- Adds exactly one custom CopyIcon import.
- Uses <CopyIcon /> for the local CopyButton.
- Resolves both Duplicate declaration "CopyIcon" errors.
